package laba2;

public class LastSkills extends Skill {

    public LastSkills(String name1,String info1) {
        super(name1,info1);
    }
}
