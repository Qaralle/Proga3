package laba2;

public class Cond {
    private String name;

    public Cond(String name1){
        this.name = name1;
    }

    public String getName(){
        return name;
    }

}
