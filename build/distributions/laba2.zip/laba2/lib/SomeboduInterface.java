package laba2;
import java.util.ArrayList;

public interface SomeboduInterface {
    String getName();
    void setSkills(ArrayList<Skill> skills);
}
