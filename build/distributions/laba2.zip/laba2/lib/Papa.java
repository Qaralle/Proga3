package laba2;

public class Papa extends Mumi {
    public Papa(String name) {
        super(name);
    }
}
