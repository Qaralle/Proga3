package laba2;

public interface Listable {
    String Getsmthinlist();
}
